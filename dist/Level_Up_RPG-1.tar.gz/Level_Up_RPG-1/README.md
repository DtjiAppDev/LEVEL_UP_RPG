# Level Up RPG

A Python package contains implementation of the game "Level Up RPG".

## Usage

The game "Level Up RPG" is a game where the player plays as long as 
he/she survives in this game. This game is about levelling up as 
much as possible and going as far as possible.